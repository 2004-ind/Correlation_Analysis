import streamlit as st
import pandas as pd
import numpy as np
import plost
import seaborn as sns
import matplotlib.pyplot as plt
import datetime
import pickle

st.set_option('deprecation.showPyplotGlobalUse', False)

# Page setting

st.set_page_config(layout="wide")

with open('style.css') as f:
    test = 'test'
    #st.markdown(f'<style>{f.read()}</style>', unsafe_allow_html=True)

# Data

with open("pivoted.pkl","rb") as f:
    
    pivoted = pickle.load(f)

with open("all_data_df.pkl","rb") as f:
    
    all_data_df = pickle.load(f)

all_data_df = all_data_df.pivot(index="Date", columns="Ticker")
all_data_df = all_data_df.dropna()
all_data_df = all_data_df['Close']
    
stocks = pd.read_csv('https://raw.githubusercontent.com/dataprofessor/data/master/stocks_toy.csv')
    
# Add sidebar


with st.sidebar:

    st.sidebar.markdown("## Correlation Between Economic Sectors")
    st.sidebar.markdown("You can **change** the values to change the *chart*.")
    st.write('Pick Sectors/Indices To Analyze')
    
    left, right = st.columns(2)
    option = [0] * 17

    with left: 

        option[1] = st.checkbox('S&P 500')
        option[2] = st.checkbox('Gold ETF')
        option[3] = st.checkbox('Volatility Index')
        option[4] = st.checkbox('Nasdaq QQQ')
        option[5] = st.checkbox('S&P 499')
        option[6] = st.checkbox('Harper Index')
        option[7] = st.checkbox('LIBOR')
        option[8] = st.checkbox('NFT Market Cap')

    with right:
        
        option[9] = st.checkbox('Gold ETF2')
        option[10] = st.checkbox('Healthcare ETF')
        option[11] = st.checkbox('Energy ETF')
        option[12] = st.checkbox('Industrials ETF')
        option[13] = st.checkbox('PPC Index')
        option[14] = st.checkbox('10yr Treasury')
        option[15] = st.checkbox('Buffalo Count')
        option[16] = st.checkbox('Market Index')


    st.write('')
    format = 'MMM DD, YYYY'  # format output
    start_date_ = datetime.date(year=1980,month=1,day=1) 
    end_date_ = datetime.datetime.now().date()
    max_days_ = end_date_ - start_date_

    start_date = st.slider('Select start date', min_value=start_date_, value=start_date_ ,max_value=end_date_, format=format)
    end_date = st.slider('Select end date', min_value=start_date_, value=end_date_ ,max_value=end_date_, format=format)
    sum = sum(option[0:16])
    st.write(sum)

if sum > 2:

    st.title("Multi Sector Comparison")
    st.write("Analysis Dashboard")

else:
    
    st.title("Head to Head Comparison")
    st.write("Analysis Dashboard")
    



# Row A

a1, a2= st.columns(2)

with a1:

    fig = plt.show()
    correlation_heatmap = sns.heatmap(pivoted.corr())
    st.pyplot(fig)


with a2:

    fig = plt.figure() #figsize=(40, 20)
    sns.lineplot(data = all_data_df)
    st.pyplot(fig)

#a1.image(Image.open('streamlit-logo-secondary-colormark-darktext.png'))
#a2.metric("Winds", "9 mph", "-8%")
#a3.metric("Humidity", "86%", "4%")

# Row B
b1, b2, b3, b4 = st.columns(4)
b1.metric("Temperature", "70 °F", "1.2 °F")
b2.metric("Wind", "9 mph", "-8%")
b3.metric("Humidity", "86%", "4%")
b4.metric("Humidity", "86%", "4%")

# Row C
c1, c2 = st.columns((7,3))
with c1:
    st.markdown('### Heatmap')
    plost.time_hist(
    data=seattle_weather,
    date='date',
    x_unit='week',
    y_unit='day',
    color='temp_max',
    aggregate='median',
    legend=None)
with c2:
    st.markdown('### Bar chart')
    plost.donut_chart(
        data=stocks,
        theta='q2',
        color='company')
